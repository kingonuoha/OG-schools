//change navbar onscroll

window.addEventListener("scroll", ()=>{
    document.querySelector("nav").classList.toggle("window-scroll", window.scrollY > 0 )
})

// SHow/Hide Faqa

const faqs = document.querySelectorAll(".faq");

faqs.forEach(faq =>{
    faq.addEventListener("click", ()=>{
        faq.classList.toggle("open");

        //change Icons

        const icon = faq.querySelector(".faq__icon i ")
        if(icon.className === "uil uil-plus"){
            icon.className = "uil uil-minus"
            icon.innerText = "-"
        }else{
            
            icon.className = "uil uil-plus"
            icon.innerText = "+"
        }
    })
})


// changing the cursur hand on drag in the testimonial 
const testimonials = document.querySelectorAll(".testimonial")
testimonials.forEach(testimonial =>{
    testimonial.addEventListener("click", ()=>{
        // alert('hi')
        // console.log("mouse down");
        testimonial.classList.toggle("dragging")
    });
})